package com.cubiq.coloros15manager

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.DataOutputStream

class MainActivity : Activity() {
    private val moduleId = "coloros15_safe_animations"
    private val moduleDir = "/data/adb/modules/$moduleId"
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (22 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            setBackgroundColor(Color.rgb(248, 246, 250))
        }
        val title = TextView(this).apply {
            text = "ColorOS 15\nAnimation Manager"
            textSize = 27f
            setTextColor(Color.rgb(35, 28, 43))
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
            setPadding(0, pad, 0, pad)
        }
        val enable = Button(this).apply {
            text = "Activar animaciones"
            setOnClickListener { runRoot("if [ -d '$moduleDir' ]; then rm -f '$moduleDir/disable'; else exit 3; fi", "Módulo activado") }
        }
        val disable = Button(this).apply {
            text = "Desactivar animaciones"
            setOnClickListener { runRoot("if [ -d '$moduleDir' ]; then touch '$moduleDir/disable'; else exit 3; fi", "Módulo desactivado") }
        }
        val refresh = Button(this).apply {
            text = "Actualizar estado"
            setOnClickListener { refreshStatus() }
        }
        val note = TextView(this).apply {
            text = "Requiere KernelSU y el módulo ColorOS 15 instalado. Los cambios se aplican al módulo; reinicia Android si el servicio ya se ejecutó en este arranque. No modifica framework, boot.img, system ni vendor."
            textSize = 13f
            setTextColor(Color.GRAY)
            setPadding(0, pad, 0, 0)
        }
        layout.addView(title)
        layout.addView(status)
        layout.addView(enable)
        layout.addView(disable)
        layout.addView(refresh)
        layout.addView(note)
        setContentView(layout)
        refreshStatus()
    }

    private fun runRoot(command: String, success: String) {
        Thread {
            val result = try {
                val process = Runtime.getRuntime().exec("su")
                DataOutputStream(process.outputStream).use {
                    it.writeBytes("$command\nexit\n")
                    it.flush()
                }
                val code = process.waitFor()
                code
            } catch (_: Exception) { -1 }
            runOnUiThread {
                if (result == 0) Toast.makeText(this, success, Toast.LENGTH_LONG).show()
                else Toast.makeText(this, "No se pudo ejecutar. Autoriza root y comprueba que el módulo esté instalado.", Toast.LENGTH_LONG).show()
                refreshStatus()
            }
        }.start()
    }

    private fun refreshStatus() {
        Thread {
            val state = try {
                val process = Runtime.getRuntime().exec(arrayOf("su", "-c",
                    "if [ ! -d '$moduleDir' ]; then echo MISSING; elif [ -f '$moduleDir/disable' ]; then echo DISABLED; else echo ENABLED; fi"))
                val output = process.inputStream.bufferedReader().readText().trim()
                process.waitFor()
                output
            } catch (_: Exception) { "NO_ROOT" }
            runOnUiThread {
                status.text = when (state) {
                    "ENABLED" -> "Estado: ACTIVADO"
                    "DISABLED" -> "Estado: DESACTIVADO"
                    "MISSING" -> "Estado: MÓDULO NO INSTALADO"
                    else -> "Estado: ROOT NO AUTORIZADO"
                }
            }
        }.start()
    }
}
