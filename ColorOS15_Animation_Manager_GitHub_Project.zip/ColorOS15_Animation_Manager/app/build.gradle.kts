plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.cubiq.coloros15manager"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.cubiq.coloros15manager"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
