# ColorOS 15 Animation Manager

Android app companion for the KernelSU module `coloros15_safe_animations`.

## What it does
- Requests root through `su`.
- Enables the module by removing its KernelSU `disable` marker.
- Disables the module by creating that marker.
- Reads and displays the module state.

## Requirements
- Android 8.0+
- KernelSU installed and working
- The matching module installed at `/data/adb/modules/coloros15_safe_animations`

## Build APK
Push this repository to GitHub. Open **Actions**, select **Build APK**, and run it (or push a commit). Download `ColorOS15-Animation-Manager` from the workflow artifacts.

## Safety
This app does not edit Android framework files, boot images, system, vendor, or SELinux policy. Root permission is used only to toggle the matching KernelSU module. Changes to an already-run boot service may require a reboot to take full effect. This app does not install the module itself.
