package com.cubiq.coloros15manager

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : Activity() {
    private val moduleId = "coloros15_safe_animations"
    private val moduleDir = "/data/adb/modules/$moduleId"
    private lateinit var status: TextView
    private lateinit var detail: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            setBackgroundColor(Color.rgb(248, 246, 250))
        }
        fun text(value: String, size: Float, color: Int = Color.DKGRAY) =
            TextView(this).apply {
                text = value
                textSize = size
                setTextColor(color)
                gravity = Gravity.CENTER
                setPadding(0, pad / 2, 0, pad / 2)
            }

        root.addView(text("ColorOS 15 Animation Manager", 24f, Color.rgb(55, 35, 75)))
        root.addView(text("Personalización de animaciones para Android / One UI", 14f))
        status = text("Comprobando KernelSU…", 16f, Color.BLACK)
        detail = text("", 13f)
        root.addView(status)
        root.addView(detail)

        fun button(label: String, action: () -> Unit) {
            root.addView(Button(this).apply {
                text = label
                setOnClickListener { action() }
            })
        }
        button("Activar módulo") { setModuleEnabled(true) }
        button("Desactivar módulo") { setModuleEnabled(false) }
        root.addView(text("Velocidad de animación", 18f, Color.BLACK))
        button("Suave · 0.5×") { setScale("0.5") }
        button("Normal · 1.0×") { setScale("1.0") }
        button("Rápida · 1.25×") { setScale("1.25") }
        button("Muy rápida · 1.5×") { setScale("1.5") }
        button("Actualizar estado") { refreshStatus() }
        root.addView(text(
            "Necesita KernelSU y el ZIP del módulo instalado. Solo cambia las tres escalas estándar de Android; no instala las animaciones propietarias de ColorOS ni modifica framework, boot, system o vendor.",
            12f, Color.GRAY
        ))
        setContentView(root)
        refreshStatus()
    }

    private fun runRoot(command: String, callback: (Int, String) -> Unit) {
        Thread {
            var code = -1
            var output = ""
            try {
                val process = ProcessBuilder("su", "-c", command)
                    .redirectErrorStream(true)
                    .start()
                output = BufferedReader(InputStreamReader(process.inputStream)).readText().trim()
                code = process.waitFor()
            } catch (e: Exception) {
                output = e.message ?: "No se pudo iniciar su"
            }
            val resultCode = code
            val resultOutput = output
            runOnUiThread { callback(resultCode, resultOutput) }
        }.start()
    }

    private fun setModuleEnabled(enabled: Boolean) {
        val command = if (enabled) {
            "test -d '$moduleDir' || exit 4; rm -f '$moduleDir/disable'; " +
            "v=${'$'}(cat '$moduleDir/config' 2>/dev/null); " +
            "case ${'$'}v in 0.5|0.75|1.0|1.25|1.5) ;; *) v=1.0 ;; esac; " +
            "settings put global window_animation_scale ${'$'}v; " +
            "settings put global transition_animation_scale ${'$'}v; " +
            "settings put global animator_duration_scale ${'$'}v; echo ENABLED"
        } else {
            "test -d '$moduleDir' || exit 4; touch '$moduleDir/disable'; " +
            "settings put global window_animation_scale 1.0; " +
            "settings put global transition_animation_scale 1.0; " +
            "settings put global animator_duration_scale 1.0; echo DISABLED"
        }
        runRoot(command) { code, output ->
            toast(if (code == 0) "Listo" else "Falló: revisa autorización root y módulo")
            refreshStatus()
        }
    }

    private fun setScale(scale: String) {
        val command = "test -d '$moduleDir' || exit 4; " +
            "test ! -f '$moduleDir/disable' || exit 5; " +
            "printf '%s\\n' '$scale' > '$moduleDir/config' || exit 6; " +
            "settings put global window_animation_scale '$scale'; " +
            "settings put global transition_animation_scale '$scale'; " +
            "settings put global animator_duration_scale '$scale'; echo OK"
        runRoot(command) { code, _ ->
            toast(if (code == 0) "Velocidad aplicada: ${scale}×" else "No se aplicó. Activa el módulo y autoriza KernelSU.")
            refreshStatus()
        }
    }

    private fun refreshStatus() {
        runRoot(
            "id; if [ ! -d '$moduleDir' ]; then echo MODULE_MISSING; " +
            "elif [ -f '$moduleDir/disable' ]; then echo MODULE_DISABLED; " +
            "else echo MODULE_ENABLED; " +
            "cat '$moduleDir/config' 2>/dev/null | head -n 1; fi"
        ) { code, output ->
            val isRoot = code == 0 && output.contains("uid=0")
            status.text = when {
                !isRoot -> "Root: no autorizado / KernelSU no disponible"
                output.contains("MODULE_MISSING") -> "Root: OK · Módulo: no instalado"
                output.contains("MODULE_DISABLED") -> "Root: OK · Módulo: desactivado"
                output.contains("MODULE_ENABLED") -> "Root: OK · Módulo: activado"
                else -> "No se pudo identificar el estado"
            }
            val scale = output.lineSequence().lastOrNull { it.trim() in setOf("0.5", "0.75", "1.0", "1.25", "1.5") }
            detail.text = if (scale != null) "Velocidad guardada: ${scale}×" else
                "Instala ColorOS15_Animations_KernelSU.zip desde KernelSU."
        }
    }

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
