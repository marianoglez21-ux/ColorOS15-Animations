@echo off
setlocal
set "VERSION=8.9"
set "DIST=gradle-%VERSION%-bin"
set "BASE=%USERPROFILE%\.gradle\wrapper\dists\%DIST%\manual"
set "GRADLE_HOME=%BASE%\gradle-%VERSION%"
set "ZIP=%BASE%\%DIST%.zip"
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  if not exist "%BASE%" mkdir "%BASE%"
  if not exist "%ZIP%" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile '%ZIP%'"
    if errorlevel 1 exit /b 1
  )
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%ZIP%' -DestinationPath '%BASE%' -Force"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_HOME%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
