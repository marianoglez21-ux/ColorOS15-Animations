# ColorOS15 Animation Manager — KernelSU

Companion APK for the KernelSU module `coloros15_safe_animations`.

## What it does
- Checks root by executing `su -c id` and verifying UID 0.
- Enables/disables the installed module using KernelSU's `disable` marker.
- Applies Android's standard window, transition and animator duration scales.
- Saves the selected scale in the module directory so `service.sh` reapplies it after boot.

## Important limitation
This is an Android/One UI personalization utility. It changes animation speed only. It does **not** contain or reproduce OPPO's proprietary ColorOS launcher/framework transition animations.

## Install
1. Install `ColorOS15_Animations_KernelSU.zip` from KernelSU Manager > Modules > Install from storage.
2. Reboot if KernelSU requests it.
3. Install the APK built by GitHub Actions and grant its root request.
4. Use the APK to enable the module and select a speed.

To revert, choose **Desactivar módulo** or remove the module in KernelSU. The standard animation scales are restored to 1.0.

## Build
Push this repository to GitHub. Open Actions and run **Build ColorOS15 Manager APK**. Download the `ColorOS15-Animation-Manager-APK` artifact.
